package scheduler;

import scheduler.db.ConnectionManager;
import scheduler.model.Caregiver;
import scheduler.model.Patient;
import scheduler.model.Vaccine;
import scheduler.model.Appointment;
import scheduler.util.Util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class Scheduler {

    // objects to keep track of the currently logged-in user
    // Note: it is always true that at most one of currentCaregiver and currentPatient is not null
    //       since only one user can be logged-in at a time
    private static Caregiver currentCaregiver = null;
    private static Patient currentPatient = null;

    public static void main(String[] args) {
        // printing greetings text
        System.out.println();
        System.out.println("Welcome to the COVID-19 Vaccine Reservation Scheduling Application!");
        System.out.println("*** Please enter one of the following commands ***");
        System.out.println("> create_patient <username> <password>");  //TODO: implement create_patient (Part 1)
        System.out.println("> create_caregiver <username> <password>");
        System.out.println("> login_patient <username> <password>");  // TODO: implement login_patient (Part 1)
        System.out.println("> login_caregiver <username> <password>");
        System.out.println("> search_caregiver_schedule <date>");  // TODO: implement search_caregiver_schedule (Part 2)
        System.out.println("> reserve <date> <vaccine>");  // TODO: implement reserve (Part 2)
        System.out.println("> upload_availability <date>");
        System.out.println("> cancel <appointment_id>");  // TODO: implement cancel (extra credit)
        System.out.println("> add_doses <vaccine> <number>");
        System.out.println("> show_appointments");  // TODO: implement show_appointments (Part 2)
        System.out.println("> logout");  // TODO: implement logout (Part 2)
        System.out.println("> quit");
        System.out.println();

        // read input from user
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in));
        while (true) {
            System.out.print("> ");
            String response = "";
            try {
                response = r.readLine();
            } catch (IOException e) {
                System.out.println("Please try again!");
            }
            // split the user input by spaces
            String[] tokens = response.split(" ");
            // check if input exists
            if (tokens.length == 0) {
                System.out.println("Please try again!");
                continue;
            }
            // determine which operation to perform
            String operation = tokens[0];
            if (operation.equals("create_patient")) {
                createPatient(tokens);
            } else if (operation.equals("create_caregiver")) {
                createCaregiver(tokens);
            } else if (operation.equals("login_patient")) {
                loginPatient(tokens);
            } else if (operation.equals("login_caregiver")) {
                loginCaregiver(tokens);
            } else if (operation.equals("search_caregiver_schedule")) {
                searchCaregiverSchedule(tokens);
            } else if (operation.equals("reserve")) {
                reserve(tokens);
            } else if (operation.equals("upload_availability")) {
                uploadAvailability(tokens);
            } else if (operation.equals("cancel")) {
                cancel(tokens);
            } else if (operation.equals("add_doses")) {
                addDoses(tokens);
            } else if (operation.equals("show_appointments")) {
                showAppointments(tokens);
            } else if (operation.equals("logout")) {
                logout(tokens);
            } else if (operation.equals("quit")) {
                System.out.println("Bye!");
                return;
            } else {
                System.out.println("Invalid operation name!");
            }
        }
    }

    private static void createPatient(String[] tokens) {
        // TODO: Part 1
        // create_caregiver <username> <password>
        // check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Failed to create user.");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];
        // check 2: check if the username has been taken already
        if (usernameExistsPatient(username)) {
            System.out.println("Username taken, try again!");
            return;
        }
        byte[] salt = Util.generateSalt();
        byte[] hash = Util.generateHash(password, salt);
        // create the patient
        try {
            Patient patient = new Patient.PatientBuilder(username, salt, hash).build();
            // save patient information to our database
            patient.saveToDB();
            System.out.println("Created user " + username);
        } catch (SQLException e) {
            System.out.println("Failed to create user.");
            e.printStackTrace();
        }

    }
    private static boolean usernameExistsPatient(String username) {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String selectUsername = "SELECT * FROM Patients WHERE Username = ?";
        try {
            PreparedStatement statement = con.prepareStatement(selectUsername);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            // returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
            return resultSet.isBeforeFirst();
        } catch (SQLException e) {
            System.out.println("Error occurred when checking username");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
        return true;
    }

    private static void createCaregiver(String[] tokens) {
        // create_caregiver <username> <password>
        // check 1: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Failed to create user.");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];
        // check 2: check if the username has been taken already
        if (usernameExistsCaregiver(username)) {
            System.out.println("Username taken, try again!");
            return;
        }
        byte[] salt = Util.generateSalt();
        byte[] hash = Util.generateHash(password, salt);
        // create the caregiver
        try {
            Caregiver caregiver = new Caregiver.CaregiverBuilder(username, salt, hash).build(); 
            // save to caregiver information to our database
            caregiver.saveToDB();
            System.out.println("Created user " + username);
        } catch (SQLException e) {
            System.out.println("Failed to create user.");
            e.printStackTrace();
        }
    }

    private static boolean usernameExistsCaregiver(String username) {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String selectUsername = "SELECT * FROM Caregivers WHERE Username = ?";
        try {
            PreparedStatement statement = con.prepareStatement(selectUsername);
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            // returns false if the cursor is not before the first record or if there are no rows in the ResultSet.
            return resultSet.isBeforeFirst();
        } catch (SQLException e) {
            System.out.println("Error occurred when checking username");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }
        return true;
    }

    private static void loginPatient(String[] tokens) {
        // login_patient <username> <password>
        // check 1: if someone's already logged-in, they need to log out first
        if (currentCaregiver != null || currentPatient != null) {
            System.out.println("User already logged in.");
            return;
        }
        // check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Login failed.");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];

        Patient patient = null;
        try {
            patient = new Patient.PatientGetter(username, password).get();
        } catch (SQLException e) {
            System.out.println("Login failed.");
            e.printStackTrace();
        }
        // check if the login was successful
        if (patient == null) {
            System.out.println("Login failed.");
        } else {
            System.out.println("Logged in as: " + username);
            currentPatient = patient;
        }
    }
    private static void loginCaregiver(String[] tokens) {
        // login_caregiver <username> <password>
        // check 1: if someone's already logged-in, they need to log out first
        if (currentCaregiver != null || currentPatient != null) {
            System.out.println("User already logged in.");
            return;
        }
        // check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Login failed.");
            return;
        }
        String username = tokens[1];
        String password = tokens[2];

        Caregiver caregiver = null;
        try {
            caregiver = new Caregiver.CaregiverGetter(username, password).get();
        } catch (SQLException e) {
            System.out.println("Login failed.");
            e.printStackTrace();
        }
        // check if the login was successful
        if (caregiver == null) {
            System.out.println("Login failed.");
        } else {
            System.out.println("Logged in as: " + username);
            currentCaregiver = caregiver;
        }
    }

private static void searchCaregiverSchedule(String[] tokens) {
    if (currentPatient == null && currentCaregiver == null) {
        System.out.println("Please login first!");
        return;
    }

    if (tokens.length != 2) {
        System.out.println("Please try again!");
        return;
    }

    String dateString = tokens[1];

    try {
        Date date = Date.valueOf(dateString);

        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        try {
            String getCaregiverSchedule = "SELECT c.Username AS Username, " +
                    "v.Name AS VaccineName, " +
                    "v.Doses AS Doses " +
                    "FROM Caregivers c " +
                    "LEFT JOIN Availabilities a ON c.Username = a.Username AND a.Time = ? " +
                    "LEFT JOIN Vaccines v ON a.VaccineName = v.Name " +
                    "ORDER BY c.Username";

            PreparedStatement statement = con.prepareStatement(getCaregiverSchedule);
            statement.setDate(1, date);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String caregiverUsername = resultSet.getString("Username");
                String vaccineName = resultSet.getString("VaccineName");
                int availableDoses = resultSet.getInt("Doses");

                System.out.println(caregiverUsername + " " + vaccineName + " " + availableDoses);
            }

        } catch (SQLException e) {
            System.out.println("Please try again!");
            e.printStackTrace();
        } finally {
            cm.closeConnection();
        }

    } catch (IllegalArgumentException e) {
        System.out.println("Please enter a valid date!");
    }
}
    private static void reserve(String[] tokens) {
        try {
            // Check if a patient is logged in
            if (currentPatient == null) {
                System.out.println("Please login as a patient!");
                return;
            }

            // Extract date and vaccine name from tokens
            if (tokens.length != 3) {
                System.out.println("Please try again!");
                return;
            }
            String dateString = tokens[1];
            String vaccineName = tokens[2];

            // Parse the date
            try {
                Date date = Date.valueOf(dateString);

                // Find an available caregiver for the given date
                String caregiverUsername = findAvailableCaregiver(date);
                if (caregiverUsername == null) {
                    System.out.println("No Caregiver is available!");
                    return;
                }

                // Check if there are enough available doses for the specified vaccine
                Vaccine vaccine = new Vaccine.VaccineGetter(vaccineName).get();
                if (vaccine == null) {
                    System.out.println("Vaccine not found!");
                    return;
                }

                int dosesNeeded = 1; // Assuming one dose per appointment
                if (vaccine.getAvailableDoses() >= dosesNeeded) {
                    // Decrement available doses in the vaccine
                    vaccine.decreaseAvailableDoses(dosesNeeded);

                    // Generate and print appointment ID
                    int appointmentId = generateAppointmentId();

                    System.out.println("Appointment ID: " + appointmentId + ", Caregiver username: " + caregiverUsername);
                    Appointment.AppointmentBuilder appointmentBuilder = new Appointment.AppointmentBuilder(appointmentId)
                            .appointmentDate(dateString)
                            .patientName(currentPatient.getUsername())
                            .caregiverName(caregiverUsername)
                            .vaccineName(vaccineName);

                    Appointment appointment = appointmentBuilder.build();
                    appointment.saveToDB();
                } else {
                    System.out.println("Not enough available doses!");
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Please enter a valid date!");
            } catch (SQLException e) {
                System.out.println("Please try again!");
                e.printStackTrace();
            }
        } catch (Exception e) {
            System.out.println("Please try again!");
            e.printStackTrace();
        }
    }

    private static String findAvailableCaregiver(Date date) throws SQLException {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String getAvailableCaregiver = "SELECT TOP 1 Username FROM Availabilities WHERE Time = ? " +
                "AND NOT EXISTS (SELECT 1 FROM Appointments app WHERE app.CaregiverName = Availabilities.Username AND app.AppointmentDate = ?)";

        try {
            PreparedStatement statement = con.prepareStatement(getAvailableCaregiver);
            statement.setDate(1, date);
            statement.setDate(2, date);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getString("Username");
            } else {
                return null; // No available caregiver found
            }
        } finally {
            cm.closeConnection();
        }
    }
    private static int generateAppointmentId() {
        return appointmentCounter++;
    }

    private static int appointmentCounter = 1;


    private static void uploadAvailability(String[] tokens) {
        // upload_availability <date>
        // check 1: check if the current logged-in user is a caregiver
        if (currentCaregiver == null) {
            System.out.println("Please login as a caregiver first!");
            return;
        }
        // check 2: the length for tokens need to be exactly 2 to include all information (with the operation name)
        if (tokens.length != 2) {
            System.out.println("Please try again!");
            return;
        }
        String date = tokens[1];
        try {
            Date d = Date.valueOf(date);
            currentCaregiver.uploadAvailability(d);
            System.out.println("Availability uploaded!");
        } catch (IllegalArgumentException e) {
            System.out.println("Please enter a valid date!");
        } catch (SQLException e) {
            System.out.println("Error occurred when uploading availability");
            e.printStackTrace();
        }
    }

    private static void cancel(String[] tokens) {
        // Check if a user is logged in
        if (currentPatient == null && currentCaregiver == null) {
            System.out.println("Please login first!");
            return;
        }

        // Check if the correct number of arguments is provided
        if (tokens.length != 2) {
            System.out.println("Please try again!");
            return;
        }

        try {
            int appointmentId = Integer.parseInt(tokens[1]);

            // Check if the appointment exists
            Appointment appointment = getAppointmentById(appointmentId);
            if (appointment == null) {
                System.out.println("Appointment not found!");
                return;
            }

            if (currentPatient != null && !appointment.getPatientName().equals(currentPatient.getUsername())) {
                System.out.println("You don't have permission to cancel this appointment!");
                return;
            }

            if (currentCaregiver != null && !appointment.getCaregiverName().equals(currentCaregiver.getUsername())) {
                System.out.println("You don't have permission to cancel this appointment!");
                return;
            }

            // Cancel the appointment
            cancelAppointment(appointment);
            System.out.println("Appointment canceled successfully!");
        } catch (NumberFormatException e) {
            System.out.println("Invalid appointment ID!");
        } catch (SQLException e) {
            System.out.println("Please try again!");
            e.printStackTrace();
        }
    }

    private static Appointment getAppointmentById(int appointmentId) throws SQLException {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String query = "SELECT * FROM Appointments WHERE AppointmentID = ?";
        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, appointmentId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return new Appointment.AppointmentBuilder(resultSet.getInt("AppointmentID"))
                        .appointmentDate(resultSet.getString("AppointmentDate"))
                        .patientName(resultSet.getString("PatientName"))
                        .caregiverName(resultSet.getString("CaregiverName"))
                        .build();
            } else {
                return null;
            }
        } finally {
            cm.closeConnection();
        }
    }

    private static void cancelAppointment(Appointment appointment) throws SQLException {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String deleteAppointment = "DELETE FROM Appointments WHERE AppointmentID = ?";
        try {
            PreparedStatement statement = con.prepareStatement(deleteAppointment);
            statement.setInt(1, appointment.getAppointmentId());
            statement.executeUpdate();
        } finally {
            cm.closeConnection();
        }
    }


    private static void addDoses(String[] tokens) {
        // add_doses <vaccine> <number>
        // check 1: check if the current logged-in user is a caregiver
        if (currentCaregiver == null) {
            System.out.println("Please login as a caregiver first!");
            return;
        }
        // check 2: the length for tokens need to be exactly 3 to include all information (with the operation name)
        if (tokens.length != 3) {
            System.out.println("Please try again!");
            return;
        }
        String vaccineName = tokens[1];
        int doses = Integer.parseInt(tokens[2]);
        Vaccine vaccine = null;
        try {
            vaccine = new Vaccine.VaccineGetter(vaccineName).get();
        } catch (SQLException e) {
            System.out.println("Error occurred when adding doses");
            e.printStackTrace();
        }
        // check 3: if getter returns null, it means that we need to create the vaccine and insert it into the Vaccines
        //          table
        if (vaccine == null) {
            try {
                vaccine = new Vaccine.VaccineBuilder(vaccineName, doses).build();
                vaccine.saveToDB();
            } catch (SQLException e) {
                System.out.println("Error occurred when adding doses");
                e.printStackTrace();
            }
        } else {
            // if the vaccine is not null, meaning that the vaccine already exists in our table
            try {
                vaccine.increaseAvailableDoses(doses);
            } catch (SQLException e) {
                System.out.println("Error occurred when adding doses");
                e.printStackTrace();
            }
        }
        System.out.println("Doses updated!");
    }

    private static void showAppointments(String[] tokens) {
        try {
            // Check if a user is logged in
            if (currentPatient == null && currentCaregiver == null) {
                System.out.println("Please login first!");
                return;
            }

            // Display appointments for caregivers
            if (currentCaregiver != null) {
                try {
                    List<String> caregiverAppointments = getCaregiverAppointments(currentCaregiver);
                    for (String appointment : caregiverAppointments) {
                        System.out.println(appointment);
                    }
                } catch (SQLException e) {
                    System.out.println("Please try again!");
                    e.printStackTrace();
                }
            }

            // Display appointments for patients
            if (currentPatient != null) {
                try {
                    List<String> patientAppointments = getPatientAppointments(currentPatient);
                    for (String appointment : patientAppointments) {
                        System.out.println(appointment);
                    }
                } catch (SQLException e) {
                    System.out.println("Please try again!");
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            System.out.println("Please try again!");
            e.printStackTrace();
        }
    }

    private static List<String> getCaregiverAppointments(Caregiver caregiver) throws SQLException {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String query = "SELECT AppointmentID, VaccineName, AppointmentDate, PatientName " +
                "FROM Appointments " +
                "WHERE CaregiverName = ? " +
                "ORDER BY AppointmentID";

        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, caregiver.getUsername());
            ResultSet resultSet = statement.executeQuery();

            List<String> appointments = new ArrayList<>();
            while (resultSet.next()) {
                int appointmentId = resultSet.getInt("AppointmentID");
                String vaccineName = resultSet.getString("VaccineName");
                Date date = resultSet.getDate("AppointmentDate");
                String patientUsername = resultSet.getString("PatientName");

                appointments.add(appointmentId + " " + vaccineName + " " + date + " " + patientUsername);
            }
            return appointments;
        } finally {
            cm.closeConnection();
        }
    }
    private static List<String> getPatientAppointments(Patient patient) throws SQLException {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String query = "SELECT AppointmentID, VaccineName, AppointmentDate, CaregiverName " +
                "FROM Appointments " +
                "WHERE PatientName = ? " +
                "ORDER BY AppointmentID";

        try {
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, patient.getUsername());
            ResultSet resultSet = statement.executeQuery();

            List<String> appointments = new ArrayList<>();
            while (resultSet.next()) {
                int appointmentId = resultSet.getInt("AppointmentID");
                String vaccineName = resultSet.getString("VaccineName");
                Date date = resultSet.getDate("AppointmentDate");
                String caregiverUsername = resultSet.getString("CaregiverName");

                appointments.add("Appointment ID: " + appointmentId + " " + "Vaccine: " + vaccineName + " " + "Date: " + date + " " + "Caregiver: " + caregiverUsername);
            }
            return appointments;
        } finally {
            cm.closeConnection();
        }
    }
    private static void logout(String[] tokens) {
        try {
            if (currentPatient == null && currentCaregiver == null) {
                System.out.println("Please login first!");
                return;
            }
            currentPatient = null;
            currentCaregiver = null;
            System.out.println("Successfully logged out!");
        } catch (Exception e) {
            System.out.println("Please try again!");
            e.printStackTrace();
        }
    }

}
