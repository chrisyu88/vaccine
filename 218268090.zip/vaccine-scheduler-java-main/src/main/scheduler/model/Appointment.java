package scheduler.model;

import scheduler.db.ConnectionManager;
import scheduler.util.Util;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Appointment {
    private final int appointmentId;
    private final String appointmentDate;
    private final String patientName;
    private final String caregiverName;
    private final String vaccineName;

    private Appointment(AppointmentBuilder builder) {
        this.appointmentId = builder.appointmentId;
        this.appointmentDate = builder.appointmentDate;
        this.patientName = builder.patientName;
        this.caregiverName = builder.caregiverName;
        this.vaccineName = builder.vaccineName;
    }
    public String getVaccineName() {
        return vaccineName;
    }
    public String getPatientName() {
        return this.patientName;
    }

    public String getCaregiverName() {
        return this.caregiverName;
    }

    public int getAppointmentId() {
        return this.appointmentId;
    }
    public static class AppointmentBuilder {
        private final int appointmentId;
        private String appointmentDate;
        private String patientName;
        private String caregiverName;

        private String vaccineName;

        public AppointmentBuilder(int appointmentId) {
            this.appointmentId = appointmentId;
        }

        public AppointmentBuilder appointmentDate(String appointmentDate) {
            this.appointmentDate = appointmentDate;
            return this;
        }

        public AppointmentBuilder patientName(String patientName) {
            this.patientName = patientName;
            return this;
        }

        public AppointmentBuilder caregiverName(String caregiverName) {
            this.caregiverName = caregiverName;
            return this;
        }
        public AppointmentBuilder vaccineName(String vaccineName) {
            this.vaccineName = vaccineName;
            return this;
        }

        public Appointment build() {
            return new Appointment(this);
        }

    }

    public void saveToDB() throws SQLException {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String addAppointment = "INSERT INTO Appointments (AppointmentDate, PatientName, CaregiverName, VaccineName) VALUES (?, ?, ?,?)";
        try (PreparedStatement statement = con.prepareStatement(addAppointment)) {
            statement.setString(1, this.appointmentDate);
            statement.setString(2, this.patientName);
            statement.setString(3, this.caregiverName);
            statement.setString(4, this.vaccineName);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error occurred when saving the appointment to the database");
            e.printStackTrace();
            throw new SQLException("Error occurred when saving the appointment to the database", e);
        } finally {
            cm.closeConnection();
        }
    }
}
