package scheduler.model;
import scheduler.db.ConnectionManager;
import scheduler.util.Util;

import java.sql.*;
import java.util.Arrays;
public class Availabilities {
    private final Date date;
    private final String caregiverUsername;

    private Availabilities(AvailabilityBuilder builder) {
        this.date = builder.date;
        this.caregiverUsername = builder.caregiverUsername;
    }

    public Date getDate() {
        return date;
    }

    public String getCaregiverUsername() {
        return caregiverUsername;
    }

    public static class AvailabilityBuilder {
        private final Date date;
        private final String caregiverUsername;

        public AvailabilityBuilder(Date date, String caregiverUsername) {
            this.date = date;
            this.caregiverUsername = caregiverUsername;
        }

        public Availabilities build() {
            return new Availabilities(this);
        }
    }

    public void saveToDB() throws SQLException {
        ConnectionManager cm = new ConnectionManager();
        Connection con = cm.createConnection();

        String addAvailability = "INSERT INTO Availabilities VALUES (?, ?)";
        try {
            PreparedStatement statement = con.prepareStatement(addAvailability);
            statement.setDate(1, this.date);
            statement.setString(2, this.caregiverUsername);
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new SQLException();
        } finally {
            cm.closeConnection();
        }
    }
}
