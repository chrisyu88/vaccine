CREATE TABLE Patients (
    Username VARCHAR(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Time DATE,
    Username VARCHAR(255) REFERENCES Caregivers(Username),
    VaccineName VARCHAR(255) REFERENCES Vaccines(Name),
    PRIMARY KEY (Time, Username, VaccineName)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);

CREATE TABLE Appointments (
     AppointmentID INT PRIMARY KEY IDENTITY(1,1),
     AppointmentDate DATETIME,
     PatientName varchar(255) FOREIGN KEY REFERENCES Patients(Username),
     CaregiverName varchar(255) FOREIGN KEY REFERENCES Caregivers(Username),
     VaccineName varchar(255) FOREIGN KEY REFERENCES Vaccines(Name)
);

CREATE TABLE VaccineAdministration (
     AdministrationID INT PRIMARY KEY,
     AdministrationDate DATE,
     PatientName varchar(255) FOREIGN KEY REFERENCES Patients(Username),
     CaregiverName varchar(255) FOREIGN KEY REFERENCES Caregivers(Username),
     VaccineName varchar(255) FOREIGN KEY REFERENCES Vaccines(Name)
);